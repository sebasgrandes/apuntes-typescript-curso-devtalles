export interface Hero {
    name: string;
    realName: string;
}
