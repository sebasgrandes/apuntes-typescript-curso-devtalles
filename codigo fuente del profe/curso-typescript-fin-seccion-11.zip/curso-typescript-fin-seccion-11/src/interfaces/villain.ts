export interface Villain {
    name: string;
    dangerLevel: number;
}