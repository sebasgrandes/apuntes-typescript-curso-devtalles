"use strict";
(function () {
    var avenger = 123;
    var exists;
    var power;
    avenger = 'Dr Strange';
    // console.log( avenger.charAt(0) );
    console.log(avenger.charAt(0));
    avenger = 150.23256415;
    console.log(avenger.toFixed(2));
    console.log(exists);
    console.log(power);
})();
