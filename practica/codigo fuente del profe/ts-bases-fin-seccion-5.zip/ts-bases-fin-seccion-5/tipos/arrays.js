"use strict";
(function () {
    // const numbers: (string | number | boolean)[] = [1,2,3,4,5,'6',7,8,9,10];
    var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    var villians = ['Omega Rojo', 'Dormammu', 'Duende Verde'];
    villians.forEach(function (v) { return console.log(v.toUpperCase()); });
})();
