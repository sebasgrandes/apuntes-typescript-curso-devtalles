"use strict";
(function () {
    // strictNullChecks
    var isActive = null;
    // console.log(isActive)
})();
