"use strict";
(function () {
    var hero = 'Flash';
    function returnName() {
        return hero;
    }
    var activateBatisignal = function () {
        return 'Batiseñar activada!';
    };
    console.log(typeof activateBatisignal);
    var heroName = returnName();
})();
