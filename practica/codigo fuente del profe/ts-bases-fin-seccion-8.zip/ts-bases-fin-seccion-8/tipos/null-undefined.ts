(()=> {

    // strictNullChecks
    let isActive: boolean = null;

    

    // console.log(isActive)



})()